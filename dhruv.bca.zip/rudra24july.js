var num=100;
var str="rudra"
var booleanvar=true;

document.write("<br/>",num);
document.write("<br/>",str);
document.write("<br/>",booleanvar);

document.write("<br/>",typeof(booleanvar));

//var datatyp_______________________
var obj = new Object();
var obj ={
    FirstName: "rudra",
    lastname: "king of game",
         }
document.write("<br/>"+typeof(obj));
document.write("<br/>"+obj.FirstName+"<br/>"+obj.lastname);

//function data type----------------

var demo =function()
{
  return "hey reudra ";      
}
document.write("<br/>"+demo());
document.write("<br/>"+typeof(demo()));

//arayy datatype--------

var game=["bgmi","apex","shad"];

document.write("<br>"+game[0]+"  "+game[1]+"   "+game[2]);
//-----------------------
document.write("<br>"+game[0]);
document.write("<br>"+game[1]);
document.write("<br>"+game[2]);
//--------------------

//const variable typ-------------

const a=4;
const b=8;
const total=(a+b);
document.write("<br>"+total);
//-----------
const d=10;
const f=10;
let  total9=(f+d);
document.write("<br>"+total9);

//let variable typ ---------------------
{
let a=80;
let b=60;
let total=(a+b);
document.write("<br>"+total);
}