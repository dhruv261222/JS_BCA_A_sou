//the global method Number() can convert string to no.
// empty sting convert to 0 
// anythig else converts to Nall (not a numbers)

document.write("<br>"+Number("3.14787868")); 
document.write("<br>"+Number("  ")); 
document.write("<br>"+Number(""));
document.write("<br>"+Number("90 88")); 
 
// the globle method string ( can convert numbers to string )
 let num = 111;
 let s=String(100+23);
 document.write("<br>"+String(num)); 
 document.write("<br>"+String(123)); 
 document.write("<br>"+String(s+100+23));
 document.write("<br>"+String("100" + "23")+String("100" + "23")); 

 // the nmber method tostring ()dose the same it convert numbers to string 
 document.write("<br>"+num.toString()); 
 document.write("<br>"+String(num+num.toString())); 

 // thw to exponential () method returns a string , with the number rounded and written
 let numexp = 3.14;
 document.write("<br>"+numexp.toExponential(1)); 
 document.write("<br>"+numexp.toExponential(2)); 
 document.write("<br>"+numexp.toExponential(4)); 
 document.write("<br>"+numexp.toExponential(6)); 

 // the tofixed() return a string , with the number written with a specifide number 
 let numfixed = 3.14;
 document.write("<br>"+numfixed.toFixed()); 
 document.write("<br>"+numfixed.toFixed(2)); 
 document.write("<br>"+numfixed.toFixed(4)); 
 document.write("<br>"+numfixed.toFixed(6)); 

// the  toprecision() method return a string , with a number written with a spacified
let numprec =3.14;
document.write("<br>"+numprec.toPrecision()); 
document.write("<br>"+numprec.toPrecision(2)); 
document.write("<br>"+numprec.toPrecision(4)); 
document.write("<br>"+numprec.toPrecision(6)); 

document.write("<br/>"+Number(true));
document.write("<br/>"+Number(false));
document.write("<br/>"+Number("11"));
document.write("<br/>"+Number(" 11"));
document.write("<br/>"+Number("11"));
document.write("<br/>"+Number(" 11 "));
document.write("<br/>"+Number ("11.33"));
document.write("<br/>AAAA:"+Number ("11,33"));
document.write("<br/>"+Number("11 33")); 
document.write("<br/>"+Number ("ABC"));
document.write("<br/>"+Number(new Date("1970-01-01")));
document.write("<br/>MIN_VALUE, MAX VALUE, POSITIVE INFINITY, NEGATIVE INFINITY");

// Number Properties Cannot be Used on Variables.
//Max number possible in 15.
 document.write("<br/>"+Number.MAX_VALUE);

//Min number possible in 15.
document.write("<br/>"+Number.MIN_VALUE);
//1/0;
document.write("<br>"+Number.POSITIVE_INFINITY);